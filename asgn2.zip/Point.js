class point 
{
  constructor()
  {
    this.shape = 'point';
    this.position = [0.0, 0.0,0.0];
    this.color = [1.0,1.0,1.0,1.0];
    this.szie = 10;
  }
}